package com.taijoo.potfolioproject.util.Dialog


import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable

import android.os.Bundle
import android.view.LayoutInflater
import android.view.Window
import android.view.WindowManager
import androidx.databinding.DataBindingUtil
import com.taijoo.potfolioproject.R
import com.taijoo.potfolioproject.data.repository.room.entity.Memo
import com.taijoo.potfolioproject.databinding.CustomDialogMemoLayoutBinding
import com.taijoo.potfolioproject.presentation.view.MainActivity
import com.taijoo.potfolioproject.presentation.view.memo.MemoFragment


class MemoDeleteMessageBox(private val memoActivity: MainActivity , var item : ArrayList<Int>) : Dialog(memoActivity){

    private lateinit var binding : CustomDialogMemoLayoutBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val lpWindow = WindowManager.LayoutParams()
        lpWindow.flags = WindowManager.LayoutParams.FLAG_DIM_BEHIND
        lpWindow.dimAmount = 0.8f
        window!!.attributes = lpWindow
        requestWindowFeature(Window.FEATURE_NO_TITLE)
//        setCancelable(false)
        window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        binding = DataBindingUtil.inflate(LayoutInflater.from(memoActivity), R.layout.custom_dialog_memo_layout,null,false)


        setContentView(binding.root)

        init()
    }

    fun init(){
        //취소
        binding.frmNo.setOnClickListener {
            cancel()
        }

        //삭제
        binding.frmOk.setOnClickListener {
            for (data in item){
                memoActivity.viewModel.deleteMemoData(memoActivity.adapter.item[data].icon_seq)
            }
            memoActivity.onDeleteOkClick(1)
            dismiss()
        }
    }

}