package com.taijoo.potfolioproject.util.InterFace

interface ColorDialogInterFace {
    fun itemViewOnClick(interface_color : String , interface_type : Int , data_position : Int)
}