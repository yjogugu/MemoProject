package com.taijoo.potfolioproject.util

import android.content.res.ColorStateList
import android.graphics.Color
import android.util.Log
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.databinding.BindingAdapter
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.taijoo.potfolioproject.data.model.UserData

import com.taijoo.potfolioproject.presentation.view.CustomFragmentStateAdapter
import com.taijoo.potfolioproject.presentation.view.MainActivity
import com.taijoo.potfolioproject.presentation.view.user.UserAdapter
import com.taijoo.potfolioproject.presentation.view.user.UserClickInterface
import nl.joery.animatedbottombar.AnimatedBottomBar


object BindingAdapter {


    //메인 뷰페이지 프래그먼트 바인딩
    @BindingAdapter(value = [ "vp_fragment", "mainActivity","animatedBottomBar"])
    @JvmStatic
    fun bindMainViewPager(viewPager2: ViewPager2,fragmentArray : ArrayList<Fragment>,activity : MainActivity , animatedBottomBar: AnimatedBottomBar){
        if(viewPager2.adapter == null){
            viewPager2.setHasTransientState(true)
            viewPager2.adapter = CustomFragmentStateAdapter(activity,fragmentArray)
            viewPager2.getChildAt(0).overScrollMode = RecyclerView.OVER_SCROLL_NEVER
            animatedBottomBar.setupWithViewPager2(viewPager2)
        }
    }


    @BindingAdapter(value = ["bind_user_list","userClickInterface"])
    @JvmStatic
    fun bindUserList(recyclerView: RecyclerView, userList : MutableList<UserData>? , userClickInterface: UserClickInterface){

        if(recyclerView.adapter == null){
            val lm = LinearLayoutManager(recyclerView.context)
            val adapter = UserAdapter(userClickInterface)
            recyclerView.setHasFixedSize(true)
            recyclerView.layoutManager = lm
            recyclerView.adapter = adapter

        }
        if (userList != null) {
            (recyclerView.adapter as UserAdapter).userList = userList
        }
        recyclerView.adapter?.notifyDataSetChanged()
    }


    @BindingAdapter("profile_img")
    @JvmStatic
    fun bindViewProfile(imageView: ImageView, url : String?) {
        Glide.with(imageView.context)
            .load(IP.SERVER_ADDRESS_UPLOADS+url)
            .apply(RequestOptions().centerInside().circleCrop())
            .into(imageView)

    }

    @BindingAdapter("background_color")
    @JvmStatic
    fun bindViewBackground(constraintLayout: ConstraintLayout, icon_color_position : Int?) {
        var colorDialogItem:ArrayList<ColorDialogItem> = ArrayList()//컬러 어레이
        val colorCode = Color_Code()//컬러 코드
        colorDialogItem = colorCode.setColor()

        constraintLayout.backgroundTintList = ColorStateList.valueOf(Color.parseColor(colorDialogItem.get(icon_color_position!!).color))

    }

    @BindingAdapter("background_color_linear")
    @JvmStatic
    fun bindViewBackgroundLinearLayout(linear: LinearLayout, icon_color_position : Int?) {
        var colorDialogItem:ArrayList<ColorDialogItem> = ArrayList()//컬러 어레이
        val colorCode = Color_Code()//컬러 코드
        colorDialogItem = colorCode.setColor()

        linear.backgroundTintList = ColorStateList.valueOf(Color.parseColor(colorDialogItem.get(icon_color_position!!).color))

    }

}