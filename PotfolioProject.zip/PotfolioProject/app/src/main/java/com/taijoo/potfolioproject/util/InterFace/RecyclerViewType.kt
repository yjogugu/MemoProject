package com.taijoo.potfolioproject.util.InterFace

interface RecyclerViewType {
    val id : Long
}