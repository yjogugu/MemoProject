package com.taijoo.potfolioproject.util.InterFace

interface MemoDeleteClickInterface {
    fun itemViewOnClick(position : Int , isCheck : Boolean)
}