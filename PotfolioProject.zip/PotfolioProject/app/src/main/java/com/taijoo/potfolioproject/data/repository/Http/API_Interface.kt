package com.taijoo.potfolioproject.data.repository.Http

import com.taijoo.potfolioproject.data.model.MainData
import com.taijoo.potfolioproject.data.model.MemoData

import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.POST


interface API_Interface {


    @FormUrlEncoded
    @POST("test_count.php")
    fun test_count1(@Field("user_seq") user_seq: Int): Call<MainData>

    @FormUrlEncoded
    @POST("test_count.php")
    fun test_count(@Field("user_seq") user_seq: Int): Call<MemoData>

    //유저 정보 가져오기
    @FormUrlEncoded
    @POST("select_user_info.php")
    fun select_user_info(@Field("user_seq") user_seq: Int): Call<ResponseBody>
}