package com.taijoo.potfolioproject.util

class IP {
    companion object {
        const val SERVER_IP = "210.114.6.159"

        const val SERVER_ADDRESS = "http://yjo0909.cafe24.com/RestfulApi"

        const val SERVER_ADDRESS_UPLOADS = "http://yjo0909.cafe24.com/Uploads/"

        const val SERVER_NAME = "yjo0909.cafe24.com"
    }
}