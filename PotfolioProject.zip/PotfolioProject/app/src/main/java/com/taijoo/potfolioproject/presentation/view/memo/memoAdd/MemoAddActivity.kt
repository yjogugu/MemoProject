package com.taijoo.potfolioproject.presentation.view.memo.memoAdd

import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import com.taijoo.potfolioproject.MyApplication
import com.taijoo.potfolioproject.R
import com.taijoo.potfolioproject.databinding.ActivityMemoAddBinding
import com.taijoo.potfolioproject.presentation.view.memo.MemoFragment
import com.taijoo.potfolioproject.presentation.view.memo.MemoViewModel
import com.taijoo.potfolioproject.presentation.view.memo.MemoViewModelFactory
import com.taijoo.potfolioproject.util.InterFace.ColorDialogInterFace
import com.taijoo.potfolioproject.util.Dialog.ColorDialog

//메모 추가 View
class MemoAddActivity : AppCompatActivity(), ColorDialogInterFace  {

    lateinit var binding : ActivityMemoAddBinding
    lateinit var viewmodel : MemoViewModel
    lateinit var factory : MemoViewModelFactory

    lateinit var colorDialogInterFace : ColorDialogInterFace

    var icon_position = 0
    var icon_color_position = 0

    var viewType = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = DataBindingUtil.setContentView(this, R.layout.activity_memo_add)

//        factory = MemoViewModelFactory(application , viewType)
        viewmodel = MyApplication.instance.mainActivity.viewModel
//        viewmodel = ViewModelProvider(this@MemoAddActivity , factory)[MemoViewModel::class.java]

        binding.apply {
            binding.color = Color.parseColor("#555555")
            binding.tilMemoInput.hintTextColor = ColorStateList.valueOf(Color.parseColor("#FFFFFF"))
            lifecycleOwner = this@MemoAddActivity
        }
        colorDialogInterFace = this@MemoAddActivity

        init()
    }

    fun init(){
        //아이콘 포지션
        icon_position = intent.getIntExtra("icon_position", 0)

        //메모 저장
        binding.btOk.setOnClickListener {

            viewmodel.setDataType(1)

            viewmodel.setMemoData(icon_color_position,0, binding.memoTitleEditText.text.toString(), binding.memoEditText.text.toString())
            finish()
        }

        //배경색상 정하기
        binding.ivBackgroundColor.setOnClickListener {
            ColorDialog(this).setInterface(colorDialogInterFace,icon_color_position)

        }

        textWatcher()
    }

    //제목 이벤트 처리
    fun textWatcher(){
        binding.memoTitleEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
            }

            override fun afterTextChanged(p0: Editable?) {
                if (p0.toString().length >= 40) {
                    binding.tilMemoInput.error = getString(R.string.memo_title_error)
                } else {
                    binding.tilMemoInput.error = null
                }
            }

        })

    }


    //배경색상 및 텍스트 색상변경
    override fun itemViewOnClick(interface_color: String, interface_type: Int, data_position: Int) {
        icon_color_position = data_position

        binding.tilMemoInput.boxStrokeErrorColor = ColorStateList.valueOf(Color.parseColor("#B90101"))
        binding.tilMemoInput.setErrorTextColor(ColorStateList.valueOf(Color.parseColor("#B90101")))

        if(data_position == 13){
            binding.memoTitleEditText.setTextColor(Color.parseColor("#000000"))
            binding.tilMemoInput.hintTextColor = ColorStateList.valueOf(Color.parseColor("#000000"))
            binding.tilMemoInput.defaultHintTextColor = ColorStateList.valueOf(Color.parseColor("#000000"))
            binding.tilMemoInput.boxStrokeColor = Color.parseColor("#000000")
            binding.memoEditText.setTextColor(Color.parseColor("#000000"))
            binding.memoEditText.setHintTextColor(Color.parseColor("#000000"))
            binding.btOk.setTextColor(Color.parseColor("#000000"))
            binding.ivBackgroundColor.setColorFilter(Color.parseColor("#000000"))
        }
        else{
            binding.memoTitleEditText.setTextColor(Color.parseColor("#FFFFFF"))
            binding.tilMemoInput.hintTextColor = ColorStateList.valueOf(Color.parseColor("#FFFFFF"))
            binding.tilMemoInput.defaultHintTextColor = ColorStateList.valueOf(Color.parseColor("#FFFFFF"))
            binding.tilMemoInput.boxStrokeColor = Color.parseColor("#FFFFFF")
            binding.memoEditText.setTextColor(Color.parseColor("#FFFFFF"))
            binding.memoEditText.setHintTextColor(Color.parseColor("#FFFFFF"))
            binding.btOk.setTextColor(Color.parseColor("#FFFFFF"))
            binding.ivBackgroundColor.setColorFilter(Color.parseColor("#FFFFFF"))
        }
        binding.color = Color.parseColor(interface_color)
    }
}