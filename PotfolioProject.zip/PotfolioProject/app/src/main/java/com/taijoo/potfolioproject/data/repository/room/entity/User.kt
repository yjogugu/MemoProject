package com.taijoo.potfolioproject.data.repository.room.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "User")
data class User (
        @PrimaryKey var user_seq : Int,
        @ColumnInfo(name ="user_name") var user_name: String,
        @ColumnInfo(name = "profile") var profile : String)  {

    constructor(): this(0, "","")

}




