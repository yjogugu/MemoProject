package com.taijoo.potfolioproject.data.repository.room.Dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.taijoo.potfolioproject.data.repository.room.entity.User
import kotlinx.coroutines.flow.Flow


@Dao
interface UserDao {

    @Query("SELECT * FROM User")
    fun getUserAll(): Flow<User>


    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertUserAll(user : User)

    @Update(onConflict = OnConflictStrategy.IGNORE)
    fun updateUser(user : User)
}