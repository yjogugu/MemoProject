package com.taijoo.potfolioproject.util.InterFace

interface CompleteHandle {
    fun handle()
}