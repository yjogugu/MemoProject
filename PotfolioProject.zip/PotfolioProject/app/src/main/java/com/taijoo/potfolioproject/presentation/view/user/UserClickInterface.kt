package com.taijoo.potfolioproject.presentation.view.user

interface UserClickInterface {


    fun UserOnClick(position : Int)
}