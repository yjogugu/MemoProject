package com.taijoo.potfolioproject.data.repository.room.Database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.taijoo.potfolioproject.data.repository.room.Converters.UserConverters
import com.taijoo.potfolioproject.data.repository.room.Dao.MemoDao
import com.taijoo.potfolioproject.data.repository.room.Dao.UserDao
import com.taijoo.potfolioproject.data.repository.room.entity.Memo
import com.taijoo.potfolioproject.data.repository.room.entity.User



@Database(entities = [User::class  , Memo::class ], version = 2 , exportSchema = false)
@TypeConverters(UserConverters::class)
abstract class UserDB : RoomDatabase(){

    abstract fun userDao() : UserDao
    abstract fun memoDao() : MemoDao

    companion object{
        private var INSTANCE : UserDB? = null

        fun getInstance(context: Context):UserDB?{

            if(INSTANCE == null){
                synchronized(UserDB::class){
                    INSTANCE = Room.databaseBuilder(context.applicationContext,
                            UserDB::class.java, "User.db")
                            .fallbackToDestructiveMigration()
                            .allowMainThreadQueries()
                            .build()
                }
            }

            return INSTANCE
        }

        fun destroyInstance(){
            INSTANCE = null
        }
    }
}