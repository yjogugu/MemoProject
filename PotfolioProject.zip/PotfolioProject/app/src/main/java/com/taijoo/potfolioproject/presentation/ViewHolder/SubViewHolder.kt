package com.taijoo.potfolioproject.presentation.ViewHolder

import androidx.recyclerview.widget.RecyclerView

import com.taijoo.potfolioproject.databinding.ItemSubLayoutBinding

class SubViewHolder(var binding :ItemSubLayoutBinding) : RecyclerView.ViewHolder(binding.root) {

//    fun binding(subList : ArrayList<SubData>){
//        binding.subData2 = subList
//    }
}