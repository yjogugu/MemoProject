package com.taijoo.potfolioproject.presentation.view.memo

import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.text.method.ScrollingMovementMethod
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.LinearLayoutManager
import com.taijoo.potfolioproject.R
import com.taijoo.potfolioproject.databinding.ActivityMemoClickCustomDialogAcitivtyBinding

class MemoClickCustomDialogActivity : AppCompatActivity() {

    lateinit var binding : ActivityMemoClickCustomDialogAcitivtyBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_memo_click_custom_dialog_acitivty)

        binding = DataBindingUtil.setContentView(
            this,
            R.layout.activity_memo_click_custom_dialog_acitivty
        )


        binding.apply {
            title = intent.getStringExtra("title")//제목
            content = intent.getStringExtra("content")//내용
            date = intent.getStringExtra("date")//시간
            iconColorPosition = intent.getIntExtra("icon_color_position", 0)//메모장 색상

            //배경색이 흰색이면 텍스트색상 + close  아이콘 색상 검은색으로 변경
            if(intent.getIntExtra("icon_color_position", 0) == 13){
                ivClose.imageTintList = ColorStateList.valueOf(Color.parseColor("#000000"))
                memoText.setTextColor(Color.parseColor("#000000"))
                memoTitleText.setTextColor(Color.parseColor("#000000"))
                memoDate.setTextColor(Color.parseColor("#000000"))
            }
            else{
                ivClose.imageTintList = ColorStateList.valueOf(Color.parseColor("#FFFFFF"))
                memoText.setTextColor(Color.parseColor("#FFFFFF"))
                memoTitleText.setTextColor(Color.parseColor("#FFFFFF"))
                memoDate.setTextColor(Color.parseColor("#FFFFFF"))
            }

        }


        init()
    }


    fun init(){
        binding.ivClose.setOnClickListener {
            onBackPressed()
        }
    }

    override fun onBackPressed() {
        binding.memoText.visibility = View.GONE
        binding.ivClose.visibility = View.GONE
        super.onBackPressed()
    }
}